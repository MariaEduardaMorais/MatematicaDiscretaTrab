package com.mycompany.matematicadiscretatrab;

import org.jfree.chart.*;
import org.jfree.chart.plot.*;
import org.jfree.data.category.*;
import org.jfree.ui.*;
import Sorts.QuickSort;
import Sorts.MergeSort;
import Sorts.InsertionSortRecursive;
import java.util.Arrays;
import java.util.Random;
import org.jfree.chart.axis.CategoryAxis;
import org.jfree.chart.axis.CategoryLabelPositions;

public class MatematicaDiscretaTrab {

    public static void main(String[] args) {
        int[] inputSizes = {10, 50, 100, 1000, 10000, 100000};

        createAndShowChart("Mergesort", inputSizes);
        createAndShowChart("Inserção Recursivo", inputSizes);
        createAndShowChart("Quicksort", inputSizes);

        printTable("Mergesort", inputSizes);
        printTable("Inserção Recursivo", inputSizes);
        printTable("Quicksort", inputSizes);
    }

    public static void createAndShowChart(String algorithm, int[] inputSizes) {
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();

        for (int i = 0; i < inputSizes.length; i++) {
            int size = inputSizes[i];

            double expectedComparisons = calculateExpectedComparisons(algorithm, size);
            double actualComparisons = runSortingAlgorithm(algorithm, size);

            dataset.addValue(expectedComparisons, algorithm + " Esperado", String.valueOf(size));
            dataset.addValue(actualComparisons, algorithm + " Alcançado", String.valueOf(size));
        }

        JFreeChart chart = ChartFactory.createLineChart(
                "Comparação de Comparações Esperadas e Alcançadas - " + algorithm,
                "Tamanho de Entrada",
                "Comparações",
                dataset,
                PlotOrientation.VERTICAL,
                true,
                true,
                false
        );

        CategoryPlot plot = (CategoryPlot) chart.getPlot();
        CategoryAxis categoryAxis = plot.getDomainAxis();
        categoryAxis.setCategoryLabelPositions(CategoryLabelPositions.STANDARD);

        ChartPanel chartPanel = new ChartPanel(chart);
        chartPanel.setPreferredSize(new java.awt.Dimension(800, 600));
        ApplicationFrame frame = new ApplicationFrame("Comparação de Comparações - " + algorithm);
        frame.setContentPane(chartPanel);
        frame.pack();
        RefineryUtilities.centerFrameOnScreen(frame);
        frame.setVisible(true);
    }

    public static double calculateExpectedComparisons(String algorithm, int size) {
        double constant = 2.5;
        if (null != algorithm) {
            switch (algorithm) {
                case "Mergesort" -> {
                    return constant * size * Math.log(size) / Math.log(2);
                }
                case "Inserção Recursivo" -> {
                    return constant * size;
                }
                case "Quicksort" -> {
                    return constant * size * Math.log(size) / Math.log(2);
                }
                default -> {
                }
            }
        }
        return 0;
    }

    public static void printTable(String algorithm, int[] sizes) {
        System.out.println("Resultados para " + algorithm + "\n");
        System.out.println("Tamanho da Entrada\tComparações Esperadas\tComparações Alcançadas\tTempo (ms)");

        for (int size : sizes) {
            int[] randomArray = generateRandomArray(size);
            int[] array = Arrays.copyOf(randomArray, randomArray.length);
            runSortingAlgorithm(array, algorithm);

            double expectedComparisons = calculateExpectedComparisons(algorithm, size);
            double actualComparisons = getComparisonsForAlgorithm(algorithm);
            long executionTime = getExecutionTimeForAlgorithm(algorithm);

            System.out.printf("%d\t                %.0f\t                %.0f\t                %d\n", size, 
                                                    expectedComparisons, actualComparisons, executionTime);
        }
        System.out.println();
    }

    public static double runSortingAlgorithm(String algorithm, int size) {
        int[] randomArray = generateRandomArray(size);
        int[] array = Arrays.copyOf(randomArray, randomArray.length);
        runSortingAlgorithm(array, algorithm);

        return getComparisonsForAlgorithm(algorithm);
    }

    public static void runSortingAlgorithm(int[] array, String algorithm) {
        switch (algorithm) {
            case "Mergesort" ->
                MergeSort.mergeSort(array);
            case "Inserção Recursivo" ->
                InsertionSortRecursive.insertionSortRecursive(array, array.length);
            case "Quicksort" ->
                QuickSort.quickSort(array, 0, array.length - 1);
            default -> {
            }
        }
    }

    public static double getComparisonsForAlgorithm(String algorithm) {
        switch (algorithm) {
            case "Mergesort" -> {
                return MergeSort.getComparisons();
            }
            case "Inserção Recursivo" -> {
                return InsertionSortRecursive.getComparisons();
            }
            case "Quicksort" -> {
                return QuickSort.getComparisons();
            }
            default -> {
            }
        }
        return 0;
    }

    public static long getExecutionTimeForAlgorithm(String algorithm) {
        switch (algorithm) {
            case "Mergesort" -> {
                return MergeSort.getExecutionTime();
            }
            case "Inserção Recursivo" -> {
                return InsertionSortRecursive.getExecutionTime();
            }
            case "Quicksort" -> {
                return QuickSort.getExecutionTime();
            }
            default -> {
            }
        }
        return 0;
    }

    public static int[] generateRandomArray(int size) {
        int[] arr = new int[size];
        Random random = new Random();
        for (int i = 0; i < size; i++) {
            arr[i] = random.nextInt(1000);
        }
        return arr;
    }
}
