/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Sorts;

/**
 *
 * @author meram
 */
public class MergeSort {

    private static long comparisons = 0; // Variável para contar as comparações
    private static long startTime; // Variável para medir o tempo de início
    private static long executionTime;
    
    public static void mergeSort(int[] arr) {
        startTime = System.nanoTime(); // Inicia a medição de tempo
        mergeSortRecursive(arr);
        long endTime = System.nanoTime(); // Finaliza a medição de tempo
        executionTime = endTime - startTime;
        /*System.out.println("Mergesort:");
        System.out.println("Número de comparações: " + comparisons);
        System.out.println("Tempo gasto (em nanossegundos): " + executionTime + "\n");*/
    }

    private static void mergeSortRecursive(int[] arr) {
        if (arr.length > 1) {
            int mid = arr.length / 2;
            int[] left = new int[mid];
            int[] right = new int[arr.length - mid];

            // Copia elementos para os subarrays "left" e "right"
            System.arraycopy(arr, 0, left, 0, mid);
            for (int i = mid; i < arr.length; i++) {
                right[i - mid] = arr[i];
            }

            // Chama recursivamente o Mergesort para os subarrays
            mergeSortRecursive(left);
            mergeSortRecursive(right);

            int i = 0, j = 0, k = 0;
            while (i < left.length && j < right.length) {
                if (left[i] < right[j]) {
                    arr[k] = left[i];
                    i++;
                } else {
                    arr[k] = right[j];
                    j++;
                }
                k++;
                comparisons++; // Incrementa as comparações aqui
            }

            // Copia os elementos restantes, se houver, de "left" e "right" para "arr"
            while (i < left.length) {
                arr[k] = left[i];
                i++;
                k++;
            }
            while (j < right.length) {
                arr[k] = right[j];
                j++;
                k++;
            }
        }
    }
    
    public static long getComparisons() {
        return comparisons;
    }

    public static long getExecutionTime() {
        return executionTime;
    }
}
