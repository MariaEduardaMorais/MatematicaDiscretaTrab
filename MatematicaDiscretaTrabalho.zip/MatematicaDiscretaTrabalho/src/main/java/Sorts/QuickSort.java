/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Sorts;

/**
 *
 * @author meram
 */
public class QuickSort {

    private static long comparisons = 0; // Variável para contar as comparações
    private static long startTime; // Variável para medir o tempo de início
    private static long executionTime; // Variável para armazenar o tempo gasto

    public static void quickSort(int[] arr, int low, int high) {
        comparisons = 0; // Zera a contagem de comparações
        startTime = System.nanoTime(); // Inicia a medição de tempo
        quickSortHelper(arr, low, high);
        long endTime = System.nanoTime(); // Finaliza a medição de tempo
        executionTime = endTime - startTime;
    }

    private static void quickSortHelper(int[] arr, int low, int high) {
        if (low < high) {
            int pi = partition(arr, low, high);
            quickSortHelper(arr, low, pi - 1);
            quickSortHelper(arr, pi + 1, high);
        }
    }

    private static int partition(int[] arr, int low, int high) {
        int pivot = arr[high];
        int i = (low - 1);
        for (int j = low; j < high; j++) {
            if (arr[j] < pivot) {
                i++;
                int temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
                comparisons++; // Incrementa a contagem de comparações
            }
        }
        int temp = arr[i + 1];
        arr[i + 1] = arr[high];
        arr[high] = temp;
        comparisons++; // Incrementa a contagem de comparações
        return i + 1;
    }

    public static long getComparisons() {
        return comparisons;
    }

    public static long getExecutionTime() {
        return executionTime;
    }
}
