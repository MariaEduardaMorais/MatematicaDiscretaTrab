/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Sorts;

/**
 *
 * @author meram
 */
public class InsertionSortRecursive {

    private static long comparisons = 0; // Variável para contar as comparações
    private static long startTime; // Variável para medir o tempo de início
    private static long executionTime; // Variável para armazenar o tempo gasto

    public static void insertionSortRecursive(int[] arr, int n) {
        comparisons = 0; // Zera a contagem de comparações
        startTime = System.nanoTime(); // Inicia a medição de tempo
        insertionSortRecursiveHelper(arr, n);
        long endTime = System.nanoTime(); // Finaliza a medição de tempo
        executionTime = endTime - startTime;
    }

    private static void insertionSortRecursiveHelper(int[] arr, int n) {
        for (int i = 1; i < n; i++) {
            int key = arr[i];
            int j = i - 1;

            while (j >= 0 && arr[j] > key) {
                arr[j + 1] = arr[j];
                j--;
                comparisons++; // Incrementa a contagem de comparações
            }

            arr[j + 1] = key;
        }
    }

    public static long getComparisons() {
        return comparisons;
    }

    public static long getExecutionTime() {
        return executionTime;
    }
}


